# Durak Arena — Telegram Mini App starter

This is the first code scaffold based on the card references supplied in chat.

## Included
- React/Vite mobile-first Mini App UI (play, shop, profile tabs)
- 36-card deck model (4 suits × ranks 6–A)
- Selectable cards, table display, 20-second countdown and warning counter demo
- Stake selector: 100, 200, 500, 1,000, 2,000, 5,000, 10,000, 50,000, 100,000
- 95% winner / 5% house-fee calculation shown in the interface
- FastAPI starter with room creation, room state and WebSocket endpoint
- Uploaded card-back and card-face reference images in `assets/`

## Run the Mini App locally
```bash
cd frontend
npm install
npm run dev
```
Open the local Vite URL shown in the terminal.

## Run the API
```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```
Health check: `http://localhost:8000/health`

## Connect Telegram later
1. Create a bot with @BotFather and configure its Web App URL after deploying the frontend over HTTPS.
2. Add a bot webhook/command handler and verify Telegram `initData` on the backend before trusting user IDs or profile data.
3. Connect the Mini App to `/rooms` and `/ws/{room_id}` using your deployed API URL.
4. Implement authenticated matchmaking, complete Durak turn rules, server-side 20-second deadlines, three-warning removal, reconnect handling and persistent room state before public release.
5. Implement Telegram Stars invoices for digital coin/skin purchases. Validate successful payments server-side and keep all coins non-withdrawable and non-transferable for cash value.

## Important implementation status
This is a runnable **UI prototype + API scaffold**, not a finished public multiplayer game. The countdown, hand and card interactions currently run in the browser demo. The backend room endpoint is a starting point; it does not yet enforce full game rules, synchronize live moves, process Stars payments or persist balances. Do not deploy it with real purchases until authentication, database transactions, anti-cheat and payment validation are implemented.

## Card art
The two user-provided references are preserved in `assets/`. The red patterned reverse is represented by a CSS prototype. The supplied face sheet is a reference collage rather than a complete, clean 36-card sprite atlas; the prototype draws card faces in CSS. Individual card art can be sliced/redrawn after you provide a complete front-face set or approve the generated vector style.
