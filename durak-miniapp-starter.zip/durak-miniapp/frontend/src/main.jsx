import React, {useEffect, useMemo, useState} from 'react';
import {createRoot} from 'react-dom/client';
import './style.css';

const SUITS = [{s:'♠',c:'black'},{s:'♣',c:'black'},{s:'♦',c:'red'},{s:'♥',c:'red'}];
const RANKS = ['6','7','8','9','10','J','Q','K','A'];
const STAKES = [100,200,500,1000,2000,5000,10000,50000,100000];
const money = n => n.toLocaleString('en-US').replaceAll(',', '.');
function makeDeck(){ return SUITS.flatMap(s=>RANKS.map((r,i)=>({id:s.s+r,rank:r,suit:s.s,color:s.c,value:i+6}))); }
function Card({card,back=false,onClick,selected=false,small=false}){
  if(back) return <div className={`playing-card back ${small?'small':''}`}><div className="back-pattern"><span>✥</span><b>✧</b><span>✥</span></div></div>;
  return <button className={`playing-card face ${card.color} ${selected?'selected':''} ${small?'small':''}`} onClick={onClick} type="button"><span className="corner top">{card.rank}<i>{card.suit}</i></span><strong>{card.suit}</strong><span className="corner bottom">{card.rank}<i>{card.suit}</i></span></button>
}
function App(){
 const [tab,setTab]=useState('play'), [stake,setStake]=useState(100), [players,setPlayers]=useState(2), [hand,setHand]=useState([]), [table,setTable]=useState([]), [selected,setSelected]=useState(null), [seconds,setSeconds]=useState(20), [warnings,setWarnings]=useState(0), [coins,setCoins]=useState(2500), [notice,setNotice]=useState('Stolga karta tashlang yoki kesing');
 const [started,setStarted]=useState(false);
 const deck=useMemo(()=>makeDeck(),[]);
 function startGame(){let d=[...deck].sort(()=>Math.random()-.5);setHand(d.slice(0,6));setTable([]);setSeconds(20);setWarnings(0);setStarted(true);setSelected(null);setNotice('Sizning navbatingiz');}
 useEffect(()=>{if(!started)return;const t=setInterval(()=>setSeconds(s=>{if(s<=1){setWarnings(w=>{const n=w+1;if(n>=3){setNotice('3 ta ogohlantirish: demo o‘yinidan chiqarildingiz');setStarted(false);return n;}setNotice(`Ogohlantirish ${n}/3 — tezroq yuring!`);return n;});return 20;}return s-1;}),1000);return()=>clearInterval(t)},[started]);
 function playCard(){if(selected===null)return;const card=hand.find(c=>c.id===selected);if(!card)return;setTable(t=>[...t,{attack:card,defend:null}]);setHand(h=>h.filter(c=>c.id!==selected));setSelected(null);setSeconds(20);setNotice('Karta tashlandi. Raqib javobini kuting');}
 function defend(){if(selected===null||!table.length)return;const card=hand.find(c=>c.id===selected);const last=table[table.length-1];if(!card)return;const beats=card.suit===last.attack.suit&&card.value>last.attack.value || card.suit==='♥'&&last.attack.suit!=='♥';if(!beats){setNotice('Бу карта билан кесиб бўлмайди');return;}setTable(t=>t.map((x,i)=>i===t.length-1?{...x,defend:card}:x));setHand(h=>h.filter(c=>c.id!==selected));setSelected(null);setSeconds(20);setNotice('Карта кесилди');}
 const pot=stake*players; const fee=Math.floor(pot*.05);
 return <div className="app">
  <header><div className="brand"><div className="logo">♠</div><div><b>DURAK <em>ARENA</em></b><small>TELEGRAM CARD CLUB</small></div></div><div className="balance">🪙 {money(coins)}</div></header>
  <nav><button className={tab==='play'?'active':''} onClick={()=>setTab('play')}>Ўйин</button><button className={tab==='shop'?'active':''} onClick={()=>setTab('shop')}>Магазин</button><button className={tab==='profile'?'active':''} onClick={()=>setTab('profile')}>Профиль</button></nav>
  {tab==='play'&&<>
   <section className="hero"><div><span className="eyebrow">ONLINE MULTIPLAYER</span><h1>Карта майдони</h1><p>Дўстларингиз билан 2–4 киши бўлиб ўйнанг.</p></div><div className="live"><i/> LIVE</div></section>
   <section className="setup"><div className="field"><label>ЎЙИНЧИЛАР</label><div className="seg">{[2,3,4].map(n=><button key={n} className={players===n?'chosen':''} onClick={()=>setPlayers(n)}>{n} киши</button>)}</div></div><div className="field"><label>СТАВКА</label><div className="stakes">{STAKES.map(n=><button key={n} className={stake===n?'chosen':''} onClick={()=>setStake(n)}>{money(n)}</button>)}</div></div><div className="potline"><span>Ўртадаги умумий монета</span><b>🪙 {money(pot)}</b></div><div className="potline muted"><span>Ғолиб 95% / комиссия 5%</span><b>{money(pot-fee)} / {money(fee)}</b></div><button className="primary" onClick={startGame}>{started?'Қайта бошлаш':'Ўйинни бошлаш'} <span>→</span></button><small className="hint">Демо режим: ҳозирча карталар локал тарзда тарқатилади.</small></section>
   <section className="table-area"><div className="table-top"><div className="player"><div className="avatar">👤</div><div><b>Raqib_01</b><small>6 та карта</small></div></div><div className="timer"><strong>{seconds}</strong><small>СЕКУНД</small></div><div className="player right"><div><b>@asik</b><small>{hand.length} та карта</small></div><div className="avatar mine">A</div></div></div>
    <div className="felt"><div className="table-label">{notice}</div><div className="center-cards">{table.length?table.map((pair,i)=><div className="pair" key={i}><Card card={pair.attack} small/>{pair.defend?<div className="cover"><Card card={pair.defend} small/></div>:null}</div>):<div className="empty-pile"><Card back small/><span>Карталар шу ерда очилади</span></div>}</div><div className="deck-count"><Card back small/><span>{started?'24':'36'} та</span></div></div>
    <div className="hand-label">СИЗНИНГ КАРТАЛАРИНГИЗ <span>{hand.length}/6</span></div><div className="hand">{hand.map(c=><Card key={c.id} card={c} selected={selected===c.id} onClick={()=>setSelected(selected===c.id?null:c.id)}/>)}</div><div className="actions"><button className="secondary" onClick={defend}>Кесиш / ёпиш</button><button className="primary compact" onClick={playCard}>Карта ташлаш</button></div>
   </section>
  </>}
  {tab==='shop'&&<section className="shop"><span className="eyebrow">CARD COLLECTION</span><h1>Магазин</h1><p>Карта скинлари ва монеталар — кейинги босқичда Telegram Stars билан уланади.</p><div className="skin-card"><Card back/><div><b>Classic Red</b><small>Сизнинг юборган қизил нақшли картангиз</small><span className="owned">Жорий скин</span></div></div><div className="shop-tile"><div className="coin-icon">🪙</div><div><b>Монета тўплами</b><small>Stars орқали харид қилиш тўлов интеграцияси кейин қўшилади.</small></div></div></section>}
  {tab==='profile'&&<section className="shop"><span className="eyebrow">PLAYER PROFILE</span><h1>Профиль</h1><div className="profile-card"><div className="avatar big">A</div><div><b>Telegram ўйинчи</b><small>Telegram профили уланганда ник ва расм шу ерда чиқади.</small></div></div><div className="potline"><span>Монета баланси</span><b>🪙 {money(coins)}</b></div><p className="hint">Монеталар виртуал бонус ҳисобланади. Уларни ҳақиқий пулга чиқариб бўлмайди.</p></section>}
  <footer>© DURAK ARENA <span>•</span> Виртуал монеталар пулга чиқарилмайди</footer>
 </div>
}

createRoot(document.getElementById('root')).render(<App/>);
