"""Durak Arena API starter. Run: uvicorn main:app --reload"""
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from pydantic import BaseModel, Field
from typing import Dict, List
from uuid import uuid4
import random

app = FastAPI(title="Durak Arena API", version="0.1.0")
SUITS = ["♠", "♣", "♦", "♥"]
RANKS = ["6", "7", "8", "9", "10", "J", "Q", "K", "A"]
VALUES = {rank: i for i, rank in enumerate(RANKS)}
rooms: Dict[str, dict] = {}

class CreateRoom(BaseModel):
    telegram_id: int
    username: str = "Player"
    display_name: str = "Player"
    avatar_url: str | None = None
    players: int = Field(default=2, ge=2, le=4)
    stake: int = Field(default=100, ge=100)


def new_deck():
    cards = [{"id": f"{suit}-{rank}", "suit": suit, "rank": rank, "value": VALUES[rank]} for suit in SUITS for rank in RANKS]
    random.shuffle(cards)
    return cards

@app.get("/health")
async def health():
    return {"ok": True, "service": "durak-arena"}

@app.post("/rooms")
async def create_room(data: CreateRoom):
    room_id = uuid4().hex[:8].upper()
    rooms[room_id] = {
        "id": room_id, "stake": data.stake, "max_players": data.players,
        "players": [{"telegram_id": data.telegram_id, "username": data.username,
                     "display_name": data.display_name, "avatar_url": data.avatar_url,
                     "hand": []}],
        "deck": new_deck(), "table": [], "warnings": {}, "status": "waiting"
    }
    return {"room_id": room_id, "room": public_room(rooms[room_id])}

@app.get("/rooms/{room_id}")
async def get_room(room_id: str):
    room = rooms.get(room_id.upper())
    if not room:
        return {"error": "room_not_found"}
    return public_room(room)

@app.websocket("/ws/{room_id}")
async def room_socket(ws: WebSocket, room_id: str):
    await ws.accept()
    room = rooms.get(room_id.upper())
    if not room:
        await ws.send_json({"type": "error", "message": "room_not_found"})
        await ws.close()
        return
    try:
        await ws.send_json({"type": "state", "room": public_room(room)})
        while True:
            message = await ws.receive_json()
            # The next development step adds Telegram initData verification,
            # authenticated seat assignment, turn validation and broadcasts.
            await ws.send_json({"type": "ack", "received": message.get("action", "unknown")})
    except WebSocketDisconnect:
        pass

def public_room(room):
    return {"id": room["id"], "stake": room["stake"], "max_players": room["max_players"],
            "players": [{k: p[k] for k in ("telegram_id", "username", "display_name", "avatar_url")} for p in room["players"]],
            "table": room["table"], "deck_count": len(room["deck"]), "status": room["status"]}
